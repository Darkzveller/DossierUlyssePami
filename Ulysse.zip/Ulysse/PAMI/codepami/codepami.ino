#include <Wire.h>
//#include <Arduino.h>  // Inclure pour Serial
#include <math.h>
#include <WiFi.h>
#include <PubSubClient.h>

char ssid[] = "Bbox-B44CD957";       // your network SSID (name)
char pass[] = "P%x*JFPxDY2M6Tb6";   // your network password
int status = WL_IDLE_STATUS;        // Indicator of Wifi status


char mqttServer[]     = "192.168.1.21";
char clientId[]       = "amebaClient";
char publishTopic[]   = "receive";
char publishPayload[] = "connection à la jetson effectuée";
char xTopic[] = "x_value";          // Topic for receiving x value
char yTopic[] = "y_value";          // Topic for receiving y value
char thTopic[] = "th_value";        // Topic for receibing theta value

int xValue = 0;  // Variable to store x value
int yValue = 0;  // Variable to store y value
int thValue=0;  //Variable to store theta value 

char message[10]; // Définir la longueur maximale du message

void callback(char* topic, byte* payload, unsigned int length) {
    Serial.print("Message arrived [");
    Serial.print(topic);
    Serial.print("] ");

    // Convertir le tableau de bytes en une chaîne de caractères
    for (unsigned int i = 0; i < length; i++) {
        message[i] = (char)(payload[i]);
    }
    message[length] = '\0'; // Terminer la chaîne avec un caractère nul
    Serial.println(message);

    // Vérifiez le topic et mettez à jour les valeurs de x ou y en conséquence
    if (strcmp(topic, xTopic) == 0) {
        xValue = atoi(message); // Convertir la valeur de x en entier
        Serial.print("Received x value: ");
        Serial.println(xValue);
    } else if (strcmp(topic, yTopic) == 0) {
        yValue = atoi(message); // Convertir la valeur de y en entier
        Serial.print("Received y value: ");
        Serial.println(yValue);
    } else if (strcmp(topic, thTopic)== 0){
      thValue = atoi(message);
      Serial.print("Received theta value: ");
      Serial.println(thValue);
    }

    //on vérifie si on a reçu les 3 valeurs 
    if (xValue != 0 && yValue != 0 && thValue != 0) {
        X_Y_Theta(xValue, yValue, thValue);
        Serial.println("Toutes les valeurs sont reçus, on peut éxécuter la fonction...");
        //remise à 0 des valeurs
        xValue = 0;
        yValue = 0;
        thValue = 0;
    }
}

WiFiClient wifiClient;
PubSubClient client(wifiClient);

void reconnect() {
    // Loop until we're reconnected
    while (!(client.connected())) {
        Serial.print("\r\nAttempting MQTT connection...");
        // Attempt to connect
        if (client.connect(clientId)) {
            Serial.println("connected");
            //Once connected, publish an announcement and resubscribe
            client.publish(publishTopic, publishPayload);
            client.subscribe(xTopic);
            client.subscribe(yTopic);
            client.subscribe(thTopic);
        } else {
            Serial.println("failed, rc=");
            Serial.print(client.state());
            Serial.println(" try again in 5 seconds");
            //Wait 5 seconds before retrying
            delay(5000);
        }
    }
}



#define BACKWARD 0x1
#define FORWARD 0x0



int _address = 0x10;
int32_t _gauche, _droit;
int16_t _g16, _d16;
static const int16_t MAX = 16384;
int32_t codeurGauche, codeurDroit;
int pinDirectionDroit = PA15;
int pinPWMDroit = PA13;
int pinDirectionGauche = PA14;
int pinPWMGauche = PA12;
/// Variable utiliser pour l'asservissemnt de direction
float distance = 0, erreur, commande, commandeTraiter, commandeComp = 0.1, vitesse, Kalpha = 50, PWM, PWMD, PWMG, consDistance = 0;
float m_distance;
float angle_cons_droit, angle_cons_gauche;
float rayonRoue = 60.0;
float vit_ang = 50.0;



void resetCodeur() {
  byte data[2] = { 0, 1 };
  Wire.beginTransmission(_address);
  Wire.write(data[0]);
  Wire.write(data[1]);
  Wire.endTransmission();
  _gauche = 0;
  _droit = 0;
  _g16 = 0;
  _d16 = 0;
}



void initCodeur() {
  _gauche = 0;
  _droit = 0;
  _g16 = 0;
  _d16 = 0;
  Wire.begin();
  delay(1000);
  byte data = 5, error;
  Wire.beginTransmission(_address);
  Wire.write(data);
  error = Wire.endTransmission();
  if (error == 0) {
    Serial.print("I2C device found at address 0x");
    Serial.println(_address, HEX);
    Wire.requestFrom(_address, 1);
    data = 0;
    while (Wire.available()) {  // slave may send less than requested
      data = Wire.read();       // receive a byte
    }
    Serial.print("Data = 0x");
    Serial.println(data, HEX);
  }
  resetCodeur();
}



void lectureEncodeur16_BRUT(int16_t &gauche, int16_t &droit) {
  byte data[4];
  data[0] = 1;
  Wire.beginTransmission(_address);
  Wire.write(data[0]);
  Wire.endTransmission();
  Wire.requestFrom(_address, 4);
  int i = 0;
  while (Wire.available()) {  // slave may send less than requested
    data[i++] = Wire.read();  // receive a byte
  }
  if (i == 4) {
    gauche = data[0] << 8 | (data[1] & 0xFF);
    droit = data[2] << 8 | (data[3] & 0xFF);
  }
}



void lectureEncodeur(int32_t &gauche, int32_t &droit) {
  int16_t ng, nd;
  lectureEncodeur16_BRUT(ng, nd);
  if ((ng > MAX) && (_g16 < -MAX)) {
    _gauche = _gauche - _g16 + ng - 65536;
  } else if ((ng < -MAX) && (_g16 > MAX)) {
    _gauche = _gauche - _g16 + ng + 65536;
  } else {
    _gauche = _gauche - _g16 + ng;
  }
  _g16 = ng;
  if ((nd > MAX) && (_d16 < -MAX)) {
    _droit = _droit - _d16 + nd - 65536;
  } else if ((nd < -MAX) && (_d16 > MAX)) {
    _droit = _droit - _d16 + nd + 65536;
  } else {
    _droit = _droit - _d16 + nd;
  }
  _d16 = nd;
  gauche = -1 * _gauche;
  droit = _droit;
  // Serial.print("  Codeur droit : ");
  // Serial.print(droit);
  // Serial.print("  ");
  // Serial.print("Codeur gauche : ");
  // Serial.print(gauche);
  // Serial.println();
}


////////////////////////////////////// Moteur Droit/////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Initialisation du moteur Droit/////////////////////////////////////////////////////////////////////////////////////////////////////
void initMoteurDroit() {
  pinMode(pinPWMDroit, OUTPUT);
  pinMode(pinDirectionDroit, OUTPUT);
}



//////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
void controleMoteurDroit(int PWM) {
  if (PWM > 0) {
    digitalWrite(pinDirectionDroit, 0);
  }
  if (PWM < 0) {
    digitalWrite(pinDirectionDroit, 1);
  }
  PWM = abs(PWM);
  analogWrite(pinPWMGauche, PWM);
  analogWrite(pinPWMDroit, PWM);
}



////////////////////////////////////// Moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Initialisation du moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////
void initMoteurGauche() {
  pinMode(pinPWMGauche, OUTPUT);
  pinMode(pinDirectionGauche, OUTPUT);
}



//////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
void controleMoteurGauche(int PWM) {
  if (PWM > 0) {
    digitalWrite(pinDirectionGauche, 0);
  }
  if (PWM < 0) {
    digitalWrite(pinDirectionGauche, 1);
  }
  PWM = abs(PWM);
  analogWrite(pinPWMGauche, PWM);
}



void asservissement(float cons) {
  // Serial.println(PWM);
  resetCodeur();
  delay(1000);
  do {
    lectureEncodeur(codeurGauche, codeurDroit);
    distance = (codeurGauche + codeurDroit) / 2.0;
    distance = distance * rayonRoue * 2.0 / 2048.0;
    erreur = (cons)-distance;  // Calcul de l'erreur par rapport a la consigne + une consigne d'équilibre due fait que le centre de gravité du robot n'est pas placé correctement
    commande = erreur * 0.25;  // Calcul de la commande permettant de savoir si on doit faire tourner le moteur plus ou moins fort
    if (commande < 0)          // si la commande est négatif, cela signifie qu'on doit faire tourner les moteurs dans un sens spécifiquement
    {
      commandeTraiter = commande - commandeComp;  // Etant donner que les moteur ont physiquement, un jeu et un couple de frottement sec qui doit être éliminer via un offset de la commande
      // PWMD = 10;
      // PWMG = 0;
    }
    if (commande > 0) {
      commandeTraiter = commande + commandeComp;
      // PWMG = 10;
      // PWMD = 0;
    }
    if (commandeTraiter > 1)  // Si la commande dépasse la saturation, on plafonne celle ci a une valeur fixe, due fait que le hacheur 4 quadrant a part son architecture des condensateurs de boostrap, qui doivent etre charger un peu, permettant le bon fonctionnement des transistor
    {
      commandeTraiter = 1;
      PWMD = 20;
      PWMG = 0;
    } else if (commandeTraiter < -1) {
      commandeTraiter = -1;
      PWMG = 20;
      PWMD = 0;
    }
    // Serial.println(erreur);
    // Serial.printf("avance\n");
    vitesse = 0.5 + commandeTraiter;  // Utilisant une commande unipolaire, 0.5 correspond au fait que les deux ponts du hacheur 4 quadrant donne la meme tension, ce qui fait qu'au bornes du moteur on a une tension = 0
    PWM = vitesse * Kalpha;           // On effectue une mise a l'échelle, J'ai décider de travailler sur 12bits
    controleMoteurGauche(PWM + PWMG);
    controleMoteurDroit(PWM - PWMD);
  } while ((erreur >= -2) || (erreur < 5));
}



void rotation(float angle_cons) {
  resetCodeur();
  delay(1000);
  float erreur_moyenne;
  if (angle_cons > 0) {
    angle_cons = angle_cons + 20.0;
    angle_cons_droit = angle_cons / 2.0;
    angle_cons_gauche = -1 * angle_cons_droit;
  }
  if (angle_cons < 0) {
    angle_cons = angle_cons - 20.0;
    angle_cons_droit = angle_cons / 2.0;
    angle_cons_gauche = -1 * angle_cons_droit;
  }
  do {
    lectureEncodeur(codeurGauche, codeurDroit);
    float erreur_anglegauche = (codeurGauche * rayonRoue * 2.0 / 2048.0) - (2.0 * 3.1415 * 52.0 * angle_cons_droit / 360.0);
    float erreur_angleDroit = (codeurDroit * rayonRoue * 2.0 / 2048.0) - (2.0 * 3.1415 * 52.0 * angle_cons_gauche / 360.0);
    erreur_moyenne = (erreur_anglegauche - erreur_angleDroit) / 2.0;
    // controleMoteurDroit(50);a
    // Serial.print(" erreur_moyenne ::: ");
    // Serial.print(erreur_moyenne);
    // Serial.print(" Errer dRoit ::: ");
    // Serial.print(erreur_angleDroit);
    // Serial.print("  gauche");
    // Serial.println(erreur_anglegauche);
    if (angle_cons >= 0) {
      if (erreur_moyenne < 0) {
        controleMoteurDroit(-vit_ang - (commandeComp * 255.0));
        controleMoteurGauche(vit_ang + (commandeComp * 255.0));
      }
      if (erreur_moyenne > 0) {
        controleMoteurDroit(0);
        controleMoteurGauche(0);
      }
      // if ((erreur_moyenne > 5)) {
      //   controleMoteurDroit(vit_ang + (commandeComp * 255.0));
      //   controleMoteurGauche(-vit_ang - (commandeComp * 255.0));
      // }
    } else {
      if (erreur_moyenne > 0) {
        controleMoteurDroit(20 + (commandeComp * 255.0));
        controleMoteurGauche(-20 - (commandeComp * 255.0));
      }
      if (erreur_moyenne < 0) {
        controleMoteurDroit(0);
        controleMoteurGauche(0);
      }
      // if ((erreur_moyenne < 5)) {
      //   controleMoteurDroit(-20 - (commandeComp * 255.0));
      //   controleMoteurGauche(20 + (commandeComp * 255.0));
      // }
    }
  } while ((erreur_moyenne < -2) || (erreur_moyenne > 1.5));
}



void X_Y_Theta(float x, float y, float theta) {
  float m_newX = x;
  float m_newY = y;
  float m_newTheta = theta;
  m_distance = sqrt(pow(m_newX - 1500, 2) + pow(m_newY - 1500, 2));
  // m_distance = m_distance * 47.74648;
  //calcul de l'angle en radians
  float res = (m_newY - 2000) / (m_newX - 2000);
  // Serial.println((res));
  float angle = atan2(m_newY - 2000.0, m_newX - 2000.0);
  // float angle = atan(res);
  // if (angle > 2 * PI) {
  //   angle -= 2 * PI;
  // } else if (angle < 0) {
  //   angle += 2 * PI;
  // }
  // Serial.println((angle));
  rotation(degrees(angle));
  controleMoteurDroit(0);
  controleMoteurGauche(0);
  // Serial.print("distance : ");
  // Serial.println(m_distance);
  asservissement(m_distance);
  // rotation(degrees(theta));
  // Serial.println("caca");
}



// on met un & pour faire référence à des objets déjà existants
void setup() {
  Serial.begin(115200);
  pinMode(LED_B,OUTPUT);
  pinMode(LED_G,OUTPUT);

  initCodeur();
  initMoteurDroit();
  initMoteurGauche();

      // wait for serial port to connect.
    while (!Serial) {
        ;
    }
        //Attempt to connect to WiFi network
    while (status != WL_CONNECTED) {
        Serial.print("\r\nAttempting to connect to SSID: ");
        Serial.println(ssid);
        // Connect to WPA/WPA2 network. Change this line if using open or WEP network:
        status = WiFi.begin(ssid, pass);

        // wait 10 seconds for connection:
        delay(10000);
    }

    client.setServer(mqttServer, 1883);
    client.setCallback(callback);

    //Allow Hardware to sort itself out
    delay(1500);

}





void loop() {
    if (!(client.connected())) {
      reconnect();
  }
  client.loop();
  //X_Y_Theta(xValue, yValue, thValue);
}
  // asservissement(consDistance);
  // rotation(90);
  //   controleMoteurDroit(25);
  // controleMoteurGauche(25);
  // float angle = atan2(1300 - 1500.0, 1300 - 1500.0);
//   if (i == 0) {
//     X_Y_Theta(2000, 1200, -120);
//   }
// }
// nit stat = 0;
// reculerMoteurGauche(stat);
// avanceMoteurDroit(stat);
// delay(500);
// avanceMoteurGauche(stat);
// reculerMoteurDroit(stat);
// delay(500);