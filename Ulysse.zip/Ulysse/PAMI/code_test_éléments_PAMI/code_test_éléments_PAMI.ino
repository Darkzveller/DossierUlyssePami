// #include "Codeurs.h"
// #include "Vl53l0x.h"
// #include "rgb_lcd.h"



// Vl53l0x monCapteur;
// Codeurs codeurs;
// rgb_lcd lcd;

// const int mesureVbat = PB3;

// const int TOR1 = 2;
// const int TOR2 = 3;


// int32_t codeurGauche, codeurDroit; 






// void setup() {
//   Serial.begin(115200);
//   codeurs.begin(true);
//   codeurs.reset();
//   // lcd.begin(16,2);
//   // Serial.println("test des E/S");
//   // //lcd.print("TEST LCD");
//   // codeurs.begin(false);
//   // pinMode(TOR1,INPUT_PULLUP);
//   // pinMode(TOR2,INPUT_PULLUP);
//   // pinMode(LED_B,OUTPUT);
//   // pinMode(LED_R,OUTPUT);
//   // pinMode(mesureVbat,INPUT);

//   // VL53L0X_Error status = VL53L0X_ERROR_NONE;
//   // status = monCapteur.begin(I2C_DEFAULT_ADDR, false); //true 
//   // if (VL53L0X_ERROR_NONE != status) {
//   //   Serial.println("start vl53l0x mesurement failed!");
//   //   monCapteur.printPalError(status);
//   //   while (1);
//   // }
//   // monCapteur.continuousRangingInit();
//   // if (VL53L0X_ERROR_NONE != status) {
//   //   Serial.println("start vl53l0x mesurement failed!");
//   //   monCapteur.printPalError(status);
//   //   while (1);
//   // }


// }


// void loop() {
//   int etat_TOR1 = digitalRead(TOR1);
//   int etat_TOR2 = digitalRead(TOR2);
//   float vbat = analogRead(mesureVbat);
//   float tensionBat = (vbat/895) * 3.3;
//   tensionBat = tensionBat * (7.2/3.3);

//   codeurs.read(codeurGauche,codeurDroit);
//   Serial.print("Encodeurs: ");
//   Serial.print(codeurGauche);
//   Serial.print(" ");
//   Serial.println(codeurDroit);


//   // Serial.print("tension batterie: ");
//   // Serial.println(vbat);
//   // if(tensionBat < 6.5){
//   //   lcd.setRGB(255,0,0);
//   // }else{
//   //   lcd.setRGB(0,255,0);
//   // }
//   // lcd.clear();
//   // lcd.print("vbat: ");
//   // lcd.setCursor(6,0);
//   // lcd.print(vbat);
//   // lcd.setCursor(0, 1);
//   // lcd.print("tension Bat: ");
//   // lcd.setCursor(12, 1);
//   // lcd.print(tensionBat);
//   // Serial.print(etat_TOR1);
//   // Serial.print("  ");
//   // Serial.println(etat_TOR2);
  
//   // if(etat_TOR1 == HIGH){
//   //   digitalWrite(LED_B,HIGH);
//   //   digitalWrite(LED_R, LOW);
//   // }
//   // if(etat_TOR2 == HIGH){
//   //   digitalWrite(LED_B,LOW);
//   //   digitalWrite(LED_R, HIGH);
//   // }

//   // VL53L0X_RangingMeasurementData_t rangingMeasurementData;
//   // monCapteur.performContinuousRangingMeasurement(&rangingMeasurementData);
//   // if (rangingMeasurementData.RangeMilliMeter >= 2000) {
//   //   //Serial.println("out of range");
//   //   lcd.clear();
//   //   lcd.setCursor(0, 1);
//   //   lcd.print("out of range");
//   //   lcd.setRGB(255,0,0);
//   // } else {
//   //   //Serial.print("distance:");
//   //   lcd.clear();
//   //   lcd.print("distance: ");
//   //   lcd.setCursor(10,0);
//   //   lcd.print(rangingMeasurementData.RangeMilliMeter);
//   //   //Serial.println(rangingMeasurementData.RangeMilliMeter);
//   //   lcd.setRGB(0,0,255);
//   //   //lcd.write(Serial.read());
//   // }

// }



int _address = 0x10;
int32_t _gauche, _droit;
int16_t _g16, _d16;
static const int16_t MAX = 16384;
int32_t codeurGauche, codeurDroit;
int pinDirectionDroit = PA15;
int pinPWMDroit = PA13;
int pinDirectionGauche = PA14;
int pinPWMGauche = PA12;
const int mesureVbat = PB3;
const int TOR1 = 2;
const int TOR2 = 3;


#include "Codeurs.h"

void initMoteurDroit() {
  pinMode(pinPWMDroit, OUTPUT);
  pinMode(pinDirectionDroit, OUTPUT);
}
//////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
void controleMoteurDroit(int PWM) {
  if (PWM > 0) {
    digitalWrite(pinDirectionDroit, 0);
  }
  if (PWM < 0) {
    digitalWrite(pinDirectionDroit, 1);
  }
  PWM = abs(PWM);
  analogWrite(pinPWMGauche, PWM);
  analogWrite(pinPWMDroit, PWM);
}
////////////////////////////////////// Moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Initialisation du moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////
void initMoteurGauche() {
  pinMode(pinPWMGauche, OUTPUT);
  pinMode(pinDirectionGauche, OUTPUT);
}
//////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
void controleMoteurGauche(int PWM) {
  if (PWM < 0) {
    digitalWrite(pinDirectionGauche, 1);
  }
  PWM = abs(PWM);
  analogWrite(pinPWMGauche, PWM);
  analogWrite(pinPWMDroit, PWM);
}

void setup(){
  Serial.begin(115200);
  initMoteurGauche();
  initMoteurDroit();
}


void loop(){
  controleMoteurDroit(200);
  controleMoteurGauche(200);
}