#include <WiFi.h>
#include <PubSubClient.h>

// char ssid[] = "Bbox-B44CD957";       // your network SSID (name)
// char pass[] = "P%x*JFPxDY2M6Tb6";   // your network password
char ssid[] = "TP-Link_CRAC_5G";       // your network SSID (name)
char pass[] = "CRAC94230";   // your network password
int status = WL_IDLE_STATUS;        // Indicator of Wifi status

//char mqttServer[]     = "192.168.1.21";
// char mqttServer[] = "192.168.22.102";
char mqttServer[] = "192.168.22.108";
char clientId[]       = "amebaClient";
char publishTopic[]   = "receive";
char publishPayload[] = "connection à la jetson effectuée";
char xTopic[] = "x_value";          // Topic for receiving x value
char yTopic[] = "y_value";          // Topic for receiving y value
char thTopic[] = "th_value";        // Topic for receibing theta value
char startTopic[] = "start";

int xValue = 0;  // Variable to store x value
int yValue = 0;  // Variable to store y value
int thValue=0;  //Variable to store theta value 
int start;

char message[10]; // Définir la longueur maximale du message

void callback(char* topic, byte* payload, unsigned int length) {
    Serial.print("Message arrived [");
    Serial.print(topic);
    Serial.print("] ");

    // Convertir le tableau de bytes en une chaîne de caractères
    for (unsigned int i = 0; i < length; i++) {
        message[i] = (char)(payload[i]);
    }
    message[length] = '\0'; // Terminer la chaîne avec un caractère nul
    Serial.println(message);

    // Vérifiez le topic et mettez à jour les valeurs de x ou y en conséquence
    if (strcmp(topic, xTopic) == 0) {
        xValue = atoi(message); // Convertir la valeur de x en entier
        Serial.print("Received x value: ");
        Serial.println(xValue);
    } else if (strcmp(topic, yTopic) == 0) {
        yValue = atoi(message); // Convertir la valeur de y en entier
        Serial.print("Received y value: ");
        Serial.println(yValue);
    } else if (strcmp(topic, thTopic)== 0){
      thValue = atoi(message);
      Serial.print("Received theta value: ");
      Serial.println(thValue);
    }
    // }else if(strcmp(topic,startTopic)== 0){
    //   start=atoi(message);
    //   Serial.println("valeur de start: ");
    //   Serial.println()      
    // }

    //on vérifie si on a reçu les 3 valeurs 
    if (xValue != 0 && yValue != 0 && thValue != 0) {
        Serial.println("Toutes les valeurs sont reçus, on peut éxécuter la fonction...");
        //remise à 0 des valeurs
        xValue = 0;
        yValue = 0;
        thValue = 0;
    }
                
}

WiFiClient wifiClient;
PubSubClient client(wifiClient);

void reconnect() {
    // Loop until we're reconnected
    while (!(client.connected())) {
        Serial.print("\r\nAttempting MQTT connection...");
        // Attempt to connect
        if (client.connect(clientId)) {
            Serial.println("connected");
            //Once connected, publish an announcement and resubscribe
            client.publish(publishTopic, publishPayload);
            client.subscribe(xTopic);
            client.subscribe(yTopic);
            client.subscribe(thTopic);
        } else {
            Serial.println("failed, rc=");
            Serial.print(client.state());
            Serial.println(" try again in 5 seconds");
            //Wait 5 seconds before retrying
            delay(5000);
        }
    }
}

void setup() {
    pinMode(LED_B,OUTPUT);
    pinMode(LED_G,OUTPUT);
    //Initialize serial and wait for port to open:
    Serial.begin(115200);
    // wait for serial port to connect.
    while (!Serial) {
        ;
    }

    //Attempt to connect to WiFi network
    while (status != WL_CONNECTED) {
        Serial.print("\r\nAttempting to connect to SSID: ");
        Serial.println(ssid);
        // Connect to WPA/WPA2 network. Change this line if using open or WEP network:
        status = WiFi.begin(ssid, pass);

        // wait 10 seconds for connection:
        delay(10000);
    }

    client.setServer(mqttServer, 1883);
    client.setCallback(callback);

    //Allow Hardware to sort itself out
    delay(1500);
}

void loop() {
    if (!(client.connected())) {
        reconnect();
    }
    client.loop();
}




























// /*

//  MQTT Basic example

//  This sketch demonstrates the basic capabilities of the library.
//   - connects to an MQTT server
//   - publishes "hello world" to the topic "outTopic"
//   - subscribes to the topic "inTopic", printing out any messages it receives. It assumes the received payloads are strings not binary

//  It will reconnect to the server if the connection is lost using a blocking
//  reconnect function. See the 'mqtt_reconnect_nonblocking' example for how to
//  achieve the same result without blocking the main loop.

//  Example guide:
//  https://www.amebaiot.com/en/amebad-arduino-mqtt-upload-listen/
//  */

// #include <WiFi.h>
// #include <PubSubClient.h>

// char ssid[] = "Bbox-B44CD957";       // your network SSID (name)
// char pass[] = "P%x*JFPxDY2M6Tb6";           // your network password
// int status = WL_IDLE_STATUS;        // Indicator of Wifi status


// char mqttServer[]     = "192.168.1.21";
// char clientId[]       = "amebaClient";
// char publishTopic[]   = "receive";
// char publishPayload[] = "connection à la jetson effectuée";
// char subscribeTopic[] = "reception";




// char message[10]; // Définir la longueur maximale du message

// void callback(char* topic, byte* payload, unsigned int length) {
//     Serial.print("Message arrived [");
//     Serial.print(topic);
//     Serial.print("] ");

//     // Convertir le tableau de bytes en une chaîne de caractères
//     for (unsigned int i = 0; i < length; i++) {
//         message[i] = (char)(payload[i]);
//     }
//     message[length] = '\0'; // Terminer la chaîne avec un caractère nul
//     Serial.println(message);

//     // Contrôler la LED en fonction du message reçu
//     if (strcmp(message, "start") == 0) {
//         digitalWrite(LED_B, HIGH); // Allumer la LED
//         digitalWrite(LED_G, LOW);
//         Serial.println("LED allumée");
//     } else if (strcmp(message, "stop") == 0) {
//         digitalWrite(LED_B, LOW); // Éteindre la LED
//         digitalWrite(LED_G, HIGH);
//         Serial.println("LED éteinte");
//     }
// }



//   //   // Convertir le tableau de bytes en une chaîne de caractères
//   // String message;
//   // for (unsigned int i = 0; i < length; i++) {
//   //   message += (char)payload[i];
//   // }
//   // Serial.println(message);





// WiFiClient wifiClient;
// PubSubClient client(wifiClient);

// void reconnect() {
//     // Loop until we're reconnected
//     while (!(client.connected())) {
//         Serial.print("\r\nAttempting MQTT connection...");
//         // Attempt to connect
//         if (client.connect(clientId)) {
//             Serial.println("connected");
//             //Once connected, publish an announcement and resubscribe
//             client.publish(publishTopic, publishPayload);
//             client.subscribe(subscribeTopic);
//         } else {
//             Serial.println("failed, rc=");
//             Serial.print(client.state());
//             Serial.println(" try again in 5 seconds");
//             //Wait 5 seconds before retrying
//             delay(5000);
//         }
//     }
// }

// void setup() {
//     pinMode(LED_B,OUTPUT);
//     pinMode(LED_G,OUTPUT);
//     //Initialize serial and wait for port to open:
//     Serial.begin(115200);
//     // wait for serial port to connect.
//     while (!Serial) {
//         ;
//     }

//     //Attempt to connect to WiFi network
//     while (status != WL_CONNECTED) {
//         Serial.print("\r\nAttempting to connect to SSID: ");
//         Serial.println(ssid);
//         // Connect to WPA/WPA2 network. Change this line if using open or WEP network:
//         status = WiFi.begin(ssid, pass);

//         // wait 10 seconds for connection:
//         delay(10000);
//     }

//     client.setServer(mqttServer, 1883);
//     client.setCallback(callback);

//     //Allow Hardware to sort itself out
//     delay(1500);
// }

// void loop() {
//     if (!(client.connected())) {
//         reconnect();
//     }
//     client.loop();
// }
