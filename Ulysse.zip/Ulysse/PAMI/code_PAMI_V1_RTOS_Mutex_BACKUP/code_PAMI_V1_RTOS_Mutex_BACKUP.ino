// #include <Wire.h>
// #include <Arduino.h>  // Inclure pour Serial
// #include <math.h>
// #include "Codeurs.h"
// #include "Vl53l0x.h"
// #include "rgb_lcd.h"
// #include "FreeRTOS.h"
// #include "task.h"

// Vl53l0x capteur1;
// Codeurs codeurs;
// rgb_lcd lcd;


// TaskHandle_t Handle_aTask;
// TaskHandle_t Handle_bTask;
// SemaphoreHandle_t xMutex;


// #define BACKWARD 0x1
// #define FORWARD 0x0

// int _address = 0x10;
// int32_t _gauche, _droit;
// int16_t _g16, _d16;
// static const int16_t MAX = 16384;
// int32_t codeurGauche, codeurDroit;
// int pinDirectionDroit = PA15;
// int pinPWMDroit = PA13;
// int pinDirectionGauche = PA14;
// int pinPWMGauche = PA12;
// const int mesureVbat = PB3;
// const int TOR1 = 2;
// const int TOR2 = 3;
// int etat = 0;
// int TOR1_precedent = LOW;  //laisser en LOW


// /// Variable utiliser pour l'asservissemnt de direction
// float distance = 0, erreur, commande, commandeTraiter, commandeComp = 0.1, vitesse, Kalpha = 50, PWM, PWMD, PWMG, consDistance = 0;
// float m_distance;
// float angle_cons_droit, angle_cons_gauche;
// float rayonRoue = 60.0;
// float vit_ang = 50.0;

// float distance_prec_Y = 1500;
// float distance_prec_X = distance_prec_Y;


// float Te = 10;
// float Tc = 50;


// volatile int capteurValue= 0;




// void controle(void *parameters) {
//   TickType_t xLastWakeTime;
//   xLastWakeTime = xTaskGetTickCount();

//   while (1) {
//     xSemaphoreTake(xMutex, portMAX_DELAY);
//     taskYIELD();

//     int etat_TOR1 = digitalRead(TOR1);
//     int etat_TOR2 = digitalRead(TOR2);
//     float vbat = analogRead(mesureVbat);
//     float tensionBat = (vbat / 895) * 3.3;
//     tensionBat = tensionBat * (7.2 / 3.3);

//     lcd.setCursor(7, 0);
//     lcd.print("vbat: ");
//     lcd.setCursor(12, 0);
//     lcd.print(tensionBat);

//     // if (etat_TOR1 != TOR1_precedent) {
//     //   if (etat_TOR1 == LOW) {
//     //     Serial.println("bp1 desactivé");

//     //   }else{
//     //     Serial.println("bp1 activé");
//     //   }
//     // }

//     switch (etat) {
//       case 0:
//         //lcd.setRGB(0, 0, 255);
//         if (etat_TOR1 != TOR1_precedent) {
//           if (etat_TOR1 == LOW) {
//             etat = 1;
//           }
//         }
//         break;
//       case 1:
//         //lcd.setRGB(0, 255, 0);
//         X_Y_Theta(2000, 1200, 0);
//         etat = 0;
//         break;
//       // case 2:
//       //   // Serial.println("Etat = 2");
//       //   controleMoteurDroit(0);
//       //   controleMoteurGauche(0);
//       //   break;
//     }
//     TOR1_precedent = etat_TOR1;
//     // Serial.println("Controle");
//     xSemaphoreGive(xMutex);

//     vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(Te));
//   }
// }


// void capteurs(void *parameters) {
//   TickType_t xLastWakeTime;
//   xLastWakeTime = xTaskGetTickCount();


//   while (1) {
//     xSemaphoreTake(xMutex, portMAX_DELAY);
//     // taskYIELD();
//   //   VL53L0X_RangingMeasurementData_t RangingMeasurementData;
//   //   VL53L0X_Error Status = VL53L0X_ERROR_NONE;
//   //   memset(&RangingMeasurementData, 0, sizeof(VL53L0X_RangingMeasurementData_t));
//   //   Status = capteur1.performSingleRangingMeasurement(&RangingMeasurementData);
//   //   if (VL53L0X_ERROR_NONE == Status) {
//   //     if (RangingMeasurementData.RangeMilliMeter >= 2000) {
//   //         Serial.println("out of range!!");
//   //     } else {
//   //         Serial.print("Measured distance:");
//   //         Serial.print(RangingMeasurementData.RangeMilliMeter);
//   //         Serial.println(" mm");
//   //     }
//   // } else {
//   //     Serial.print("mesurement failed !! Status code =");
//   //     Serial.println(Status);
//   // }


//     xSemaphoreGive(xMutex);

//     vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(Tc));
//   }
// }

// ////////////////////////////////////// Moteur Droit/////////////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////// Initialisation du moteur Droit/////////////////////////////////////////////////////////////////////////////////////////////////////
// void initMoteurDroit() {
//   pinMode(pinPWMDroit, OUTPUT);
//   pinMode(pinDirectionDroit, OUTPUT);
// }
// //////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
// void controleMoteurDroit(int PWM) {
//   if (PWM > 0) {
//     digitalWrite(pinDirectionDroit, 0);
//   }
//   if (PWM < 0) {
//     digitalWrite(pinDirectionDroit, 1);
//   }
//   PWM = abs(PWM);
//   analogWrite(pinPWMGauche, PWM);
//   analogWrite(pinPWMDroit, PWM);
// }
// ////////////////////////////////////// Moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////// Initialisation du moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////
// void initMoteurGauche() {
//   pinMode(pinPWMGauche, OUTPUT);
//   pinMode(pinDirectionGauche, OUTPUT);
// }
// //////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
// void controleMoteurGauche(int PWM) {
//   if (PWM > 0) {
//     digitalWrite(pinDirectionGauche, 0);
//   }
//   if (PWM < 0) {
//     digitalWrite(pinDirectionGauche, 1);
//   }
//   PWM = abs(PWM);
//   analogWrite(pinPWMGauche, PWM);
// }
// void asservissement(float cons) {
//   // Serial.println(PWM);
//   codeurs.reset();
//   delay(1000);
//   do {
//     codeurs.read(codeurGauche, codeurDroit);
//     // Serial.print("codeur Gauche  ");
//     // Serial.print(codeurGauche);
//     // Serial.print("codeur Droit  ");
//     // Serial.println(codeurDroit);
//     distance = (codeurGauche + codeurDroit) / 2.0;
//     distance = distance * rayonRoue * 2.0 / 2048.0;
//     erreur = (cons)-distance;  // Calcul de l'erreur par rapport a la consigne + une consigne d'équilibre due fait que le centre de gravité du robot n'est pas placé correctement
//     commande = erreur * 0.25;  // Calcul de la commande permettant de savoir si on doit faire tourner le moteur plus ou moins fort
//     if (commande < 0)          // si la commande est négatif, cela signifie qu'on doit faire tourner les moteurs dans un sens spécifiquement
//     {
//       commandeTraiter = commande - commandeComp;  // Etant donner que les moteur ont physiquement, un jeu et un couple de frottement sec qui doit être éliminer via un offset de la commande
//       // PWMD = 10;
//       // PWMG = 0;
//     }
//     if (commande > 0) {
//       commandeTraiter = commande + commandeComp;
//       // PWMG = 10;
//       // PWMD = 0;
//     }
//     if (commandeTraiter > 1)  // Si la commande dépasse la saturation, on plafonne celle ci a une valeur fixe, due fait que le hacheur 4 quadrant a part son architecture des condensateurs de boostrap, qui doivent etre charger un peu, permettant le bon fonctionnement des transistor
//     {
//       commandeTraiter = 1;
//       PWMD = 20;
//       PWMG = 0;
//     } else if (commandeTraiter < -1) {
//       commandeTraiter = -1;
//       PWMG = 20;
//       PWMD = 0;
//     }
//     // Serial.println(erreur);
//     // Serial.printf("avance\n");
//     vitesse = 0.5 + commandeTraiter;  // Utilisant une commande unipolaire, 0.5 correspond au fait que les deux ponts du hacheur 4 quadrant donne la meme tension, ce qui fait qu'au bornes du moteur on a une tension = 0
//     PWM = vitesse * Kalpha;           // On effectue une mise a l'échelle, J'ai décider de travailler sur 12bits
//     controleMoteurGauche(PWM + PWMG);
//     controleMoteurDroit(PWM - PWMD);
//   } while ((erreur <= -2) || (erreur > 5));
// }
// void rotation(float angle_cons) {
//   codeurs.reset();
//   delay(1000);
//   float erreur_moyenne;
//   if (angle_cons > 0) {
//     angle_cons = angle_cons + 20.0;
//     angle_cons_droit = angle_cons / 2.0;
//     angle_cons_gauche = -1 * angle_cons_droit;
//   }
//   if (angle_cons < 0) {
//     angle_cons = angle_cons - 20.0;
//     angle_cons_droit = angle_cons / 2.0;
//     angle_cons_gauche = -1 * angle_cons_droit;
//   }
//   do {
//     codeurs.read(codeurGauche, codeurDroit);
//     // Serial.print("codeur Gauche  ");
//     // Serial.print(codeurGauche);
//     // Serial.print("codeur Droit  ");
//     // Serial.println(codeurDroit);

//     float erreur_anglegauche = (codeurGauche * rayonRoue * 2.0 / 2048.0) - (2.0 * 3.1415 * 52.0 * angle_cons_droit / 360.0);
//     float erreur_angleDroit = (codeurDroit * rayonRoue * 2.0 / 2048.0) - (2.0 * 3.1415 * 52.0 * angle_cons_gauche / 360.0);
//     erreur_moyenne = (erreur_anglegauche - erreur_angleDroit) / 2.0;
//     // controleMoteurDroit(50);a
//     // Serial.print(" erreur_moyenne ::: ");
//     // Serial.print(erreur_moyenne);
//     // Serial.print(" Errer dRoit ::: ");
//     // Serial.print(erreur_angleDroit);
//     // Serial.print("  gauche");
//     // Serial.println(erreur_anglegauche);
//     if (angle_cons >= 0) {
//       if (erreur_moyenne < 0) {
//         controleMoteurDroit(-vit_ang - (commandeComp * 255.0));
//         controleMoteurGauche(vit_ang + (commandeComp * 255.0));
//       }
//       if (erreur_moyenne > 0) {
//         controleMoteurDroit(0);
//         controleMoteurGauche(0);
//       }
//       // if ((erreur_moyenne > 5)) {
//       //   controleMoteurDroit(vit_ang + (commandeComp * 255.0));
//       //   controleMoteurGauche(-vit_ang - (commandeComp * 255.0));
//       // }
//     } else {
//       if (erreur_moyenne > 0) {
//         controleMoteurDroit(20 + (commandeComp * 255.0));
//         controleMoteurGauche(-20 - (commandeComp * 255.0));
//       }
//       if (erreur_moyenne < 0) {
//         controleMoteurDroit(0);
//         controleMoteurGauche(0);
//       }
//       // if ((erreur_moyenne < 5)) {
//       //   controleMoteurDroit(-20 - (commandeComp * 255.0));
//       //   controleMoteurGauche(20 + (commandeComp * 255.0));
//       // }
//     }
//   } while ((erreur_moyenne < -2) || (erreur_moyenne > 1.5));
// }
// void X_Y_Theta(float x, float y, float theta) {
//   float m_newX = x;
//   float m_newY = y;
//   float m_newTheta = theta;
//   m_distance = sqrt(pow(m_newX - distance_prec_X, 2) + pow(m_newY - distance_prec_Y, 2));
//   // m_distance = m_distance * 47.74648;
//   //calcul de l'angle en radians
//   // float res = (m_newY - 2000) / (m_newX - 2000);
//   // Serial.println((res));
//   float angle = atan2(m_newY - distance_prec_Y, m_newX - distance_prec_X);

//   rotation(degrees(angle));
//   controleMoteurDroit(0);
//   controleMoteurGauche(0);

//   asservissement(m_distance);
//   controleMoteurDroit(0);
//   controleMoteurGauche(0);
// }


// void setup() {

//   pinMode(TOR1, INPUT_PULLUP);
//   pinMode(TOR2, INPUT_PULLUP);
//   pinMode(mesureVbat, INPUT);
//   Serial.begin(115200);
//   lcd.begin(16, 2);
//   codeurs.begin(false);
//   initMoteurDroit();
//   initMoteurGauche();
//   lcd.clear();
//   lcd.setRGB(0, 0, 255);
//   lcd.setCursor(0, 0);
//   lcd.print("PAMI 1");
//   lcd.setCursor(0, 1);
//   lcd.print("bp1 pour start");

//   //configuration capteur TOF
//   VL53L0X_Error status = VL53L0X_ERROR_NONE;
//   status = capteur1.begin(I2C_DEFAULT_ADDR, false);  //true
//   // /capteur1.begin(I2C_DEFAULT_ADDR, false);
//   capteur1.singleRangingInit();
//   if (VL53L0X_ERROR_NONE != status) {
//       Serial.println("start vl53l0x mesurement failed!");
//       capteur1.printPalError(status);
//       while (1);
//   }
//   capteur1.singleRangingInit();
//   if (VL53L0X_ERROR_NONE != status) {
//       Serial.println("start vl53l0x mesurement failed!");
//       capteur1.printPalError(status);
//       while (1);
//   }

//   xMutex = xSemaphoreCreateMutex();
//   xTaskCreate(controle, "controle", 1024, NULL, tskIDLE_PRIORITY + 3, &Handle_aTask);
//   xTaskCreate(capteurs, "capteurs", 1024, NULL, tskIDLE_PRIORITY + 1, &Handle_bTask);
// }



// void loop() {
//     VL53L0X_RangingMeasurementData_t RangingMeasurementData;
//     VL53L0X_Error Status = VL53L0X_ERROR_NONE;
//     memset(&RangingMeasurementData, 0, sizeof(VL53L0X_RangingMeasurementData_t));
//     Status = capteur1.performSingleRangingMeasurement(&RangingMeasurementData);
//     if (VL53L0X_ERROR_NONE == Status) {
//       if (RangingMeasurementData.RangeMilliMeter >= 2000) {
//           Serial.println("out of range!!");
//       } else {
//           Serial.print("Measured distance:");
//           Serial.print(RangingMeasurementData.RangeMilliMeter);
//           Serial.println(" mm");
//       }
//   } else {
//       Serial.print("mesurement failed !! Status code =");
//       Serial.println(Status);
//   }
// }



#include "Vl53l0x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "Codeurs.h"
#include "rgb_lcd.h"

Vl53l0x capteur1;
Vl53l0x capteur2;


Codeurs codeurs;
rgb_lcd lcd;


TaskHandle_t Handle_aTask;
TaskHandle_t Handle_bTask;
SemaphoreHandle_t xMutex;


#define BACKWARD 0x1
#define FORWARD 0x0

int _address = 0x10;
int32_t _gauche, _droit;
int16_t _g16, _d16;
static const int16_t MAX = 16384;
int32_t codeurGauche, codeurDroit;
int pinDirectionDroit = PA15;
int pinPWMDroit = PA13;
int pinDirectionGauche = PA14;
int pinPWMGauche = PA12;
const int mesureVbat = PB3;
const int TOR1 = 2;
const int TOR2 = 3;
int etat = 0;
int TOR1_precedent = LOW;  //laisser en LOW


/// Variable utiliser pour l'asservissemnt de direction
float distance = 0, erreur, commande, commandeTraiter, commandeComp = 0.1, vitesse, Kalpha = 50, PWM, PWMD, PWMG, consDistance = 0;
float m_distance;
float angle_cons_droit, angle_cons_gauche;
float rayonRoue = 60.0;
float vit_ang = 50.0;

float distance_prec_Y = 1500;
float distance_prec_X = distance_prec_Y;


float Te = 10;
float Tc = 50;



////////////////////////////////////// Moteur Droit/////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Initialisation du moteur Droit/////////////////////////////////////////////////////////////////////////////////////////////////////
void initMoteurDroit() {
  pinMode(pinPWMDroit, OUTPUT);
  pinMode(pinDirectionDroit, OUTPUT);
}
//////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
void controleMoteurDroit(int PWM) {
  if (PWM > 0) {
    digitalWrite(pinDirectionDroit, 0);
  }
  if (PWM < 0) {
    digitalWrite(pinDirectionDroit, 1);
  }
  PWM = abs(PWM);
  analogWrite(pinPWMGauche, PWM);
  analogWrite(pinPWMDroit, PWM);
}
////////////////////////////////////// Moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Initialisation du moteur GAUCHE/////////////////////////////////////////////////////////////////////////////////////////////////////
void initMoteurGauche() {
  pinMode(pinPWMGauche, OUTPUT);
  pinMode(pinDirectionGauche, OUTPUT);
}
//////////////////////// Permet de pouvoir déterminer dans un premier comment fonctionne les  moteurs//////////////////////////////////////////////////////
void controleMoteurGauche(int PWM) {
  if (PWM > 0) {
    digitalWrite(pinDirectionGauche, 0);
  }
  if (PWM < 0) {
    digitalWrite(pinDirectionGauche, 1);
  }
  PWM = abs(PWM);
  analogWrite(pinPWMGauche, PWM);
}
void asservissement(float cons) {
  //codeurs.reset();
  delay(1000);
  do {
    //codeurs.read(codeurGauche, codeurDroit);
  //xSemaphoreTake(xMutex, portMAX_DELAY); //on prend le mutex
    distance = (codeurGauche + codeurDroit) / 2.0;
    distance = distance * rayonRoue * 2.0 / 2048.0;
    //xSemaphoreGive(xMutex); //on relâche le mutex
    erreur = (cons)-distance;  // Calcul de l'erreur par rapport a la consigne + une consigne d'équilibre due fait que le centre de gravité du robot n'est pas placé correctement
    commande = erreur * 0.25;  // Calcul de la commande permettant de savoir si on doit faire tourner le moteur plus ou moins fort
    if (commande < 0)          // si la commande est négatif, cela signifie qu'on doit faire tourner les moteurs dans un sens spécifiquement
    {
      commandeTraiter = commande - commandeComp;  // Etant donner que les moteur ont physiquement, un jeu et un couple de frottement sec qui doit être éliminer via un offset de la commande
    }
    if (commande > 0) {
      commandeTraiter = commande + commandeComp;
    }
    if (commandeTraiter > 1)  // Si la commande dépasse la saturation, on plafonne celle ci a une valeur fixe, due fait que le hacheur 4 quadrant a part son architecture des condensateurs de boostrap, qui doivent etre charger un peu, permettant le bon fonctionnement des transistor
    {
      commandeTraiter = 1;
      PWMD = 20;
      PWMG = 0;
    } else if (commandeTraiter < -1) {
      commandeTraiter = -1;
      PWMG = 20;
      PWMD = 0;
    }
    vitesse = 0.5 + commandeTraiter;  // Utilisant une commande unipolaire, 0.5 correspond au fait que les deux ponts du hacheur 4 quadrant donne la meme tension, ce qui fait qu'au bornes du moteur on a une tension = 0
    PWM = vitesse * Kalpha;           // On effectue une mise a l'échelle, J'ai décider de travailler sur 12bits
    controleMoteurGauche(PWM + PWMG);
    controleMoteurDroit(PWM - PWMD);
  } while ((erreur <= -2) || (erreur > 5));
}
void rotation(float angle_cons) {
  //codeurs.reset();
  delay(1000);
  float erreur_moyenne;
  if (angle_cons > 0) {
    angle_cons = angle_cons + 20.0;
    angle_cons_droit = angle_cons / 2.0;
    angle_cons_gauche = -1 * angle_cons_droit;
  }
  if (angle_cons < 0) {
    angle_cons = angle_cons - 20.0;
    angle_cons_droit = angle_cons / 2.0;
    angle_cons_gauche = -1 * angle_cons_droit;
  }
  do {
    //codeurs.read(codeurGauche, codeurDroit);
    //xSemaphoreTake(xMutex,portMAX_DELAY); // on prend le mutex
    float erreur_anglegauche = (codeurGauche * rayonRoue * 2.0 / 2048.0) - (2.0 * 3.1415 * 52.0 * angle_cons_droit / 360.0);
    float erreur_angleDroit = (codeurDroit * rayonRoue * 2.0 / 2048.0) - (2.0 * 3.1415 * 52.0 * angle_cons_gauche / 360.0);
    //xSemaphoreGive(xMutex); // on relâche le mutex
    erreur_moyenne = (erreur_anglegauche - erreur_angleDroit) / 2.0;

    if (angle_cons >= 0) {
      if (erreur_moyenne < 0) {
        controleMoteurDroit(-vit_ang - (commandeComp * 255.0));
        controleMoteurGauche(vit_ang + (commandeComp * 255.0));
      }
      if (erreur_moyenne > 0) {
        controleMoteurDroit(0);
        controleMoteurGauche(0);
      }

    } else {
      if (erreur_moyenne > 0) {
        controleMoteurDroit(20 + (commandeComp * 255.0));
        controleMoteurGauche(-20 - (commandeComp * 255.0));
      }
      if (erreur_moyenne < 0) {
        controleMoteurDroit(0);
        controleMoteurGauche(0);
      }

    }
  } while ((erreur_moyenne < -2) || (erreur_moyenne > 1.5));
}
void X_Y_Theta(float x, float y, float theta) {
  float m_newX = x;
  float m_newY = y;
  float m_newTheta = theta;
  m_distance = sqrt(pow(m_newX - distance_prec_X, 2) + pow(m_newY - distance_prec_Y, 2));

  float angle = atan2(m_newY - distance_prec_Y, m_newX - distance_prec_X);

  rotation(degrees(angle));
  controleMoteurDroit(0);
  controleMoteurGauche(0);

  asservissement(m_distance);
  controleMoteurDroit(0);
  controleMoteurGauche(0);
}

void setup() {
  Serial.begin(115200);

  VL53L0X_Error status1 = VL53L0X_ERROR_NONE;
  VL53L0X_Error status2 = VL53L0X_ERROR_NONE;

  //si le programme ne start pas: vérifier les adresses des capteurs, potentielement reset

  status1 = capteur1.begin(0x29, true); 
  status2 = capteur2.begin(0x50, false);
  codeurs.begin(false);
  codeurs.reset();


  if (VL53L0X_ERROR_NONE != status1) {
    Serial.println("start vl53l0x mesurement failed!");
    capteur1.printPalError(status1);
    capteur2.printPalError(status2);
    while (1)
      ;
  }
  capteur1.continuousRangingInit();
  capteur2.continuousRangingInit();
  if (VL53L0X_ERROR_NONE != status1) {
    Serial.println("start vl53l0x mesurement failed!");
    capteur1.printPalError(status1);
    capteur2.printPalError(status2);
    while (1)
      ;
  }

  xMutex = xSemaphoreCreateMutex();                              // Create a mutex
  xTaskCreate(readSensors, "ReadSensors", 1000, NULL, 1, NULL);  // Create a task
}

void readSensors(void *pvParameters) {
  while (1) {
    xSemaphoreTake(xMutex, portMAX_DELAY);  // Take the mutex before accessing I2C

    VL53L0X_RangingMeasurementData_t rangingMeasurementData1;
    VL53L0X_RangingMeasurementData_t rangingMeasurementData2;
    capteur1.performContinuousRangingMeasurement(&rangingMeasurementData1);
    capteur2.performContinuousRangingMeasurement(&rangingMeasurementData2);
    codeurs.read(codeurGauche,codeurDroit);

    xSemaphoreGive(xMutex);  // Give the mutex back after accessing I2C

    //X_Y_Theta(2000,1200,0);

    if (rangingMeasurementData1.RangeMilliMeter >= 2000) {
      Serial.println("capteur1 out of range");
    } else if (rangingMeasurementData2.RangeMilliMeter >= 2000) {
      Serial.println("capteur 2 out of range");
    } else {
      Serial.print("distance capteur 1: ");
      Serial.print(rangingMeasurementData1.RangeMilliMeter);
      Serial.print(" distance capteur 2: ");
      Serial.print(rangingMeasurementData2.RangeMilliMeter);
      Serial.print(" Encodeurs: ");
      Serial.print(codeurGauche);
      Serial.print(" ");
      Serial.println(codeurDroit);
    }

    vTaskDelay(pdMS_TO_TICKS(100));  // Delay for 100ms
  }
}

void loop() {
  taskYIELD();
}




//PROGRAMME POUR CHANGER L ADRESSE DU CAPTEUR AVEC RTOS 


// #include "Vl53l0x.h"
// #include "FreeRTOS.h"
// #include "task.h"

// Vl53l0x capteur1;

// void setup() {
//   // put your setup code here, to run once:
//   Serial.begin(115200);

//   VL53L0X_Error status1 = VL53L0X_ERROR_NONE;
//   status1 = capteur1.begin(I2C_DEFAULT_ADDR, true);

//   if (VL53L0X_ERROR_NONE != status1) {
//     Serial.println("start vl53l0x mesurement failed!");
//     capteur1.printPalError(status1);
//     while (1);
//   }
//   capteur1.continuousRangingInit();
//   if (VL53L0X_ERROR_NONE != status1) {
//     Serial.println("start vl53l0x mesurement failed!");
//     capteur1.printPalError(status1);
//     while (1);
//   }

//   xTaskCreate(readSensor1, "ReadSensor1", 1000, NULL, 25, NULL); // Create a task
//   xTaskCreate(changeAddr, "changeAddr",1000,NULL,30,NULL);
// }


// void changeAddr(void *pvParameters){
//   VL53L0X_Error status1 = VL53L0X_ERROR_NONE;

//   status1 = capteur1.changeAddress(0x50);// Change the I2C address of the second sensor

//   if (VL53L0X_ERROR_NONE != status1) {
//     Serial.println("Impossible de changer l'adresse du capteur !");
//   }else {
//     Serial.println("Addresse changée avec succès !");
//   }


//   vTaskDelete(NULL); //pour supprimer la tâche
// }

// void readSensor1(void *pvParameters) {
//   while (1) {

//     VL53L0X_RangingMeasurementData_t rangingMeasurementData1;
//     capteur1.performContinuousRangingMeasurement(&rangingMeasurementData1);

//     if (rangingMeasurementData1.RangeMilliMeter >= 2000) {
//       // Serial.println("out of ranger");
//     } else {
//       // Serial.print("distance capteur 1: ");
//       // Serial.println(rangingMeasurementData1.RangeMilliMeter);
//     }
//     vTaskDelay(pdMS_TO_TICKS(100));
//   }
// }

// void loop() {
//   taskYIELD();

// }




//PROGRAMME POUR VERIFIER LE CHANGEMENT D ADRESSE DU CAPTEUR 

// #include "Vl53l0x.h"

// Vl53l0x monCapteur;

// void setup() {
//   // put your setup code here, to run once:
//   Serial.begin(115200);
//   VL53L0X_Error status = VL53L0X_ERROR_NONE;
//   //status = monCapteur.begin(I2C_DEFAULT_ADDR, true);
//   status = monCapteur.begin(0x50, true);
//   if (VL53L0X_ERROR_NONE != status) {
//     Serial.println("start vl53l0x mesurement failed!");
//     monCapteur.printPalError(status);
//     while (1);
//   }
//   monCapteur.continuousRangingInit();
//   if (VL53L0X_ERROR_NONE != status) {
//     Serial.println("start vl53l0x mesurement failed!");
//     monCapteur.printPalError(status);
//     while (1);
//   }
// }

// int count = 0;

// void loop() {
//   // put your main code here, to run repeatedly:
//   VL53L0X_RangingMeasurementData_t rangingMeasurementData;
//   monCapteur.performContinuousRangingMeasurement(&rangingMeasurementData);
//   if (rangingMeasurementData.RangeMilliMeter >= 2000) {
//     Serial.println("out of ranger");
//   } else {
//     Serial.print("distance::");
//     Serial.println(rangingMeasurementData.RangeMilliMeter);
//   }
//   delay(100);
//   count++;
//   VL53L0X_Error status = VL53L0X_ERROR_NONE;
//   if (count == 100) {
//     //status = monCapteur.changeAddress(0x50);
//     Serial.println("");
//     if (VL53L0X_ERROR_NONE != status) {
//       Serial.println("change address 0x50 failed!");
//       monCapteur.printPalError(status);
//       while (1);
//     }
//     //Serial.println("Change address : 0x50");
//     //Serial.println("");
//   }
// }


